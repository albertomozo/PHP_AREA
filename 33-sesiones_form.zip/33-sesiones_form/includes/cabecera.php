<!-- include de  la cabecera -->
<div id="cabecera">
           <h1>IFCD54 - PHP - Sesiones</h1>
           <h3><?php echo $empresaNombre; ?>
     
</div>