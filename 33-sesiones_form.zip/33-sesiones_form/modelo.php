<?php 
include("sesion.php");
include("includes/funciones.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <?php include("includes/header.php");?>
    <title>CV Alberto Mozo</title>
</head>
<body>
    <div id="container">
        <!-- cabecera -->
        <?php include ("includes/cabecera.php") ?>
        <!-- fin cabecera -->
        <!-- navegacion -->
        <?php include ("includes/navegacion.php") ?>
        <!-- fin navegacion> -->
        <div id="contenido">
                Contenido 
        </div>
        <!-- footer -->
        <?php include ("includes/pie.php") ?>
        <!-- fin footer -->
          





    </div> 
</body>
</html>